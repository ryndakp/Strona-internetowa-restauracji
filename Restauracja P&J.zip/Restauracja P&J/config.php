<?php 

$con = mysqli_connect("localhost","root","","restauracja");
	if(!$con)
	{
		die('No connection');
	}
	  /* echo "Connected successfully";   */

?>
